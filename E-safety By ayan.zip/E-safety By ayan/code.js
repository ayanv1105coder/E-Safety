var battery = 10;
setImageURL("image1", "assets/download.png");
hideElement("text_area1");
hideElement("text_area2");
hideElement("button4");
hideElement("label7");
onEvent("imastuedent", "click", function( ) {
  setScreen("studentscreen");
  setTimeout(function() {
    battery = 5;
    setImageURL("image1", "assets/images.png");
  }, 120000);
  setTimeout(function() {
    battery = 3;
    setImageURL("image1", "download-(1).png");
  }, 300000);
  if (battery == 3) {
    showElement("text_area1");
    showElement("text_area2");
    showElement("button4");
    showElement("label7");
  }
  onEvent("button4", "click", function( ) {
    hideElement("text_area1");
    hideElement("text_area2");
    hideElement("button4");
    hideElement("label7");
    battery = 10;
    setImageURL("image1", "assets/download.png");
  });
});
onEvent("back", "click", function( ) {
  setScreen("firstpage");
});
onEvent("password", "click", function( ) {
  setScreen("passwordscreen");
});
onEvent("button7", "click", function( ) {
  setScreen("studentscreen");
});
onEvent("imaparent", "click", function( ) {
  setScreen("parentscreen");
});
onEvent("button9", "click", function( ) {
  setScreen("firstpage");
});
onEvent("button10", "click", function( ) {
  setScreen("parentscreen2");
});
onEvent("button11", "click", function( ) {
  setScreen("parentscreen");
});
onEvent("button12", "click", function( ) {
  setScreen("parentscreen2");
});
onEvent("button13", "click", function( ) {
  setScreen("parentscreen3");
});
onEvent("button14", "click", function( ) {
  setScreen("screen8");
});
onEvent("button15", "click", function( ) {
  setScreen("parentscreen3");
});
onEvent("button16", "click", function( ) {
  setScreen("screen9");
});
onEvent("button17", "click", function( ) {
  setScreen("screen8");
});
onEvent("button18", "click", function( ) {
  setScreen("screen10");
});
onEvent("button19", "click", function( ) {
  setScreen("screen9");
});
onEvent("button20", "click", function( ) {
  setScreen("screen11");
});
onEvent("button21", "click", function( ) {
  setScreen("screen10");
});
onEvent("more", "click", function( ) {
  setScreen("screen12");
});
onEvent("button22", "click", function( ) {
  setScreen("firstpage");
});
onEvent("button27", "click", function( ) {
  open("https://studio.code.org/projects/applab/IZ1JYvZj1be-ED6XyNcvd0UrS32YMH9-fNYZMf2ZIsc");
});
onEvent("sendbtn", "click", function( ) {
  setText("text", getText("send"));
  setProperty("send", "text", "Bug report has been sent");
});
onEvent("button6", "click", function( ) {
  setScreen("firstpage");
});
onEvent("button3", "click", function( ) {
  setScreen("screen2");
});
